/** @deprecated Import from ./core/streaming instead */
export * from './core/streaming';
