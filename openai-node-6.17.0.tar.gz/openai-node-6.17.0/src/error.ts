/** @deprecated Import from ./core/error instead */
export * from './core/error';
