/** @deprecated Import from ./core/api-promise instead */
export * from './core/api-promise';
