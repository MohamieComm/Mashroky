export const VERSION = '6.17.0'; // x-release-please-version
