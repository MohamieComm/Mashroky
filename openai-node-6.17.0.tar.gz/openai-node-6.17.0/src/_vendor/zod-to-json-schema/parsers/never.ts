export type JsonSchema7NeverType = {
  not: {};
};

export function parseNeverDef(): JsonSchema7NeverType {
  return {
    not: {},
  };
}
