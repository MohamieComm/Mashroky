# Partial JSON Parser

Vendored from https://www.npmjs.com/package/partial-json with some modifications
