# openai-bun-test

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run index.ts
```
